// src/components/HomeContent.tsx
import Image from 'next/image';

export default function HomeContent() {
    return (
        <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
            <section className="md:col-span-2 space-y-4">
                <Image
                    src="/dorm.jpg"
                    alt="Eselsbergsteige Dormitory Building"
                    width={800}
                    height={500}
                    className="rounded-xl shadow-lg"
                    priority
                />
                <p className="leading-relaxed text-gray-700 dark:text-gray-300">
                    Welcome to Eselsbergsteige dormitory! This website is directed to freshmen…
                </p>
                <p className="leading-relaxed text-gray-700 dark:text-gray-300">
                    We, the tutors of this dormitory, want to emphasize that we are not the carrier…
                </p>
            </section>

            <aside className="space-y-6">
                {/* subscribe + events */}
            </aside>
        </div>
    );
}
