// next.config.js

/** @type {import('next').NextConfig} */
const nextConfig = {
    // your existing options…
    images: {
        domains: [],
    },
};

module.exports = nextConfig;
