module.exports = {
  plugins: {
    // use the standalone Tailwind plugin package
    'tailwindcss/nesting': {},
    tailwindcss: {},
    autoprefixer: {},
  },
}
