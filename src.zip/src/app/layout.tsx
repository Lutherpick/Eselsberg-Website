// src/app/layout.tsx
import './globals.css'
import { ThemeProvider } from 'next-themes'
import Layout from '@/components/Layout'    // ← import your header/footer wrapper

export const metadata = {
    title: 'Eselsbergsteige Dormitory',
    description: 'Info & resources for residents',
}

export default function RootLayout({
                                       children,
                                   }: {
    children: React.ReactNode
}) {
    return (
        <html lang="en">
        <body>
        <ThemeProvider attribute="class">
            {/* a11y skip link */}
            <a href="#main-content" className="skip-link">
                Skip to content
            </a>

            {/* Wrap everything in your Layout so Header & Footer show up */}
            <Layout>
                {children}
            </Layout>
        </ThemeProvider>
        </body>
        </html>
    )
}
